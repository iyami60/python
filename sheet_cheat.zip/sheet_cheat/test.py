"""
import <nom de module>
from <nom de module> import {<nom_function> or *}
"""
import os
os.system("cls")
coucou = lambda:print("hello people")
calculer = lambda a,b: print(a+b)
calculer(5,6)