import numpy as np
import pandas as pd

df = pd.read_csv ('C:\\Users\\ISSAM\\Desktop\\dd')
print(df)