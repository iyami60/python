import matplotlib.pyplot as plt
import numpy as np

def f(x):
    return np.power(x,4) + 2*np.power(x,2) + 1
b = 0.4
x0 = -0.2
x1 = (x0*f(b)-b*f(x0))/(f(b)-f(x0))

while(np.abs(x-x0)>eps):
    x0 = x1
    x1 = (x0*f(b)-b*f(x0))/(f(b)-f(x0))
    