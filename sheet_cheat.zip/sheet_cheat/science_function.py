simport datetime as dt
import re
from easygui import * 
import numpy as np 
list_0 = [4,5,16,2,3,9,8,7]
list_1 = ["hamza","said","salim","emane","karim","dodo","daif","soufiane"]
"""
for i, value in enumerate(list_0):
    #print("the value of item {} is {}".format(i,value))


for one, two in zip(list_0,list_1):
    #print("first: {}, seconde: {}".format(one, two))
"""
date = dt.datetime.now()
str = "hello issam we're here to saluate yous"
a = re.search("issam",str) #string contain a result of search.


np.eye(5)

