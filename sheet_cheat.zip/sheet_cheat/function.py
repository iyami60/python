"""
function in python like: print() , typr(), float()
                bool(), str(), input();
"""
import os
os.system("cls")
##############
age = input("donner votre age!!:")
age = float(age)

def dire_bonj():
    print("hello tous le monde!.")

def dire(no_personne ="Issam", message="bonjour"):
    print("{} : {}".format(no_personne,message))
    #l'ordre du parametre et plus important

dire("hamza","bonjour") #parametre personnalise
dire()      #a des parametre par defaut!.

def show_items(*list_items):
    for item in list_items:
        print(item)
show_items("épée","sword","shield","cape","magie")