import os
os.system("cls")
##################
d = dict()
for i in range(1, 100):
    d[i] = True

for i in range(2, 100):
    if d[i]:
        for j in range(2, 100):
            if i * j < 100:
                d[i * j] = False

#print("liste des nombres premiers")
for i in d:
    if d[i]:
        print(i)
#####################################
#print(7**4)