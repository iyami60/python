import matplotlib.pyplot as plt
import numpy as np
 
def f(x):
    return np.power(x,4) + 2*np.power(x,2) + 1
def g(x):
    return 4*np.power(x,3) + 4*x

x = np.linspace(-0.5,0.5,50)
y =f(x)
y1 =g(x)
plt.plot(x,y,'r',x,y1,'b')
plt.show()