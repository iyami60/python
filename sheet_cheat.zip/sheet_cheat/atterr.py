import numpy as np
relax = np.zeros((10,10))
def croisement():
    print("croisement")
def mutation():
    print("mutation")

#remplissage de relaxation
relax[0][1] = 3
relax[1][0] = 3
for i in range(3,10):
    for j in range(3,10):
        if(i!=j):
            relax[i][j] = 8
for i in range(2,10):
    for j in range(0,2):
        relax[i][j] = 15
for i in range(0,2):
    for j in range(2,10):
        relax[i][j] = 15
#########################
individu = np.zeros(10)
depart = np.array([192,195,89,96,110,120,124,126,135,160])
arrivee =np.array([559,744,510,521,555,576,577,573,591,657])
Y = np.zeros(10)
######################
for i in range(0,10):
    a,b = depart[i],arrivee[i]
    x = np.random.randint(a,b)
    Y[i] = x

for i in range(0,10):
    j=1
    flag = True
    if(i == 0):
        individu[i] = Y[i]
    else:
        while(flag):
            s = Y[i]-Y[j]
            if(abs(s)>=relax[i][j]):
                individu[i] = Y[i]      
                flag = False
            else:
                a,b = depart[i],arrivee[i]
                x = np.random.randint(a,b)
                Y[i] = x
                j = j+1

print("individu est: \n")
print(individu)