from random import *
from platform import python_version

def greet_user(username): 
    """Display a simple greeting.""" 
    print("Hello! " + username) 

def factoriel(x):
    if x==0:
        return 1
    else:
        return x*factoriel(x-1)

def nombre_de_fois_devise_sur_2(x):
    a = 0
    while x % 2 == 0 :
        a = a+1
        x = x // 2
    return a


""" 1* somme des inputs 
somme = 0
a=int(input("entrer un nombre: "))
while a > 0:
    a=int(input("entrer un nombre: "))
    somme = somme + a
print(somme)  
"""

def e_approximation(n):
    somme = 0.0
    for i in range(n+1):
        somme = somme + 1/factoriel(i)
    return somme

# x = int(input("donner un nombre entre 2 .. 100 : "))
def listAleaFloat(x):
    """
    def listAleaFloat(n) :
    "Retourne une liste de <n> flottants aléatoires"
    return [random() for i in range(n)]
    """
    myList = []
    for i in range(x):
        myList.append(uniform(2,100))
    return myList
 
def average(list):
    somme = 0
    for i in range(len(list)):
        somme += list[i]
    return somme/len(list)

def amplitude(list):
    amp = max_list(list) - min_list(list)
    return amp

listOn = [10, 18, 14, 20, 12, 16]
def MaxMoyMin(list):
    return max(list),min(list),average(list)

"""
numList = [19, 21, 46]
strList = ['one', 'two', 'three']

outputA = zip(numList, strList)

x, y = zip(*outputA )
print('numList = ', x)
print('strlist = ', y)
"""

def random_dee():
    return randint(1,6),randint(1,6),randint

def possibilite_of(x,nombre_des):
    posibilite = 0
    if nombre_des == 2:
        for i in range(1,7):
            for j in range(1,7):
                s=i+j
                if s==x:
                    posibilite+=1
    else:
        for i in range(1,7):
            for j in range(1,7):
                for k in range(1,7):
                    s = i+j+k
                    if s == x:
                        posibilite+=1
    return posibilite

print(possibilite_of(6,3))
print(possibilite_of(6,2))

print(python_version())