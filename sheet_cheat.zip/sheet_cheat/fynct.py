import matplotlib.pyplot as plt
import numpy as np
 
def function1(x):
    return (2*x*x) + 2*x
def function2(x):
    return (0.5-np.sin(x))


x = np.linspace(-1,1.4,50)
y1 = function1(x)
y2 = function2(x)


#x0 = (3+5)/2
#print(function(x0))

plt.plot(x,y2,'b')
#plt.show()
k = 0
a = -1
b = 5
xm = (a+b)/2
e = 8*np.power(1/2,5)
for k in range(1,100):
    if(function1(a)*function1(xm)<0):
        a=xm
        xm=(a+b)/2
        print("iteration", k ,":",a,b,function1(a),function1(b),xm, np.abs(a-b))
    else:
        b=xm
        xm=(a+b)/2
        print("iteration", k ,":",a,b,function1(a),function1(b),xm,np.abs(a-b))
    if(np.abs(a-b)<e):
        break;
print(xm,function1(xm),k)
            

