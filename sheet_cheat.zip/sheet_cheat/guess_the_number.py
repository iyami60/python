import random

x = int(input("entrer un numbre: "))
alea = random.randint(1,1000)

while x != alea:
    if x < alea:
        if alea - 20 < x < alea + 20:
            print("yeah keep increase, too close")
        else:
            print("lowest, but too bad!!" )
    if x > alea:
        if alea - 20 < x < alea + 20:
            print("yeah keep decrease, too close")
        else:
            print("highest, but too bad!!")
    x = int(input("essayer à nouveau: "))
if x == alea:
        print("you're right, congrats !!")

print(alea)