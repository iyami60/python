import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate
import pylab as py


x =  np.r_[0:10:100j]         # np.linspace(0,10,11)
xnew =   np.r_[0:10:10j]                 #np.linspace(0,10,100)
y = np.sin(x)

py.plot(x,y)

for kind in ['linear']:
    f = interpolate.interp1d(x,y, kind=kind)
    ynew = f(xnew) 
    py.plot(xnew,ynew,label=kind)   
py.figure(1)
py.legend(loc="lower right")
py.show()

#interpolation de lagrange
# dans l'intervale [1,20]

#plt.plot(x,y,'b','ro')
#plt.plot(xnew,ynew,'r','b-')
#plt.show()