def printHello():
    print("Hello issam")

sum = lambda x1,x2:x1+x2
