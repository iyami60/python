import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

tips = sns.load_dataset('tips')

#distribution as (distplot)
#kde = FALSE  TRANSFORM TO A histogram parametre
sns.distplot(tips['total_bill'])

#joinplot used to make difference between two variables in dataset
#kind = {"“scatter”,“reg”,“resid”,“kde”,“hex"}; parametre
x,y = "total_bill",'tip'
dt=tips
sns.jointplot(x=x,y=y,data=dt)

#see pairplot / rugplot /kernel

""" categorical plot (barplot,countplot,violinplot,boxplot)   """
#barplot  --estimator
sns.barplot(x='sex', y='total_bill',data=tips)
#countplot --count the occurence of categorical parametre
sns.countplot(x='sex',data=tips)
sns.violinplot(x="day", y="total_bill", data=tips,palette='rainbow')
plt.show(sns.boxplot(x="day", y="total_bill", data=tips))
