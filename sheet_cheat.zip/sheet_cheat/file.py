""" create a file called "test1.txt" an initale bby text
f = open("test1.txt","w")
f.write("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer eleifend sem dui, non volutpat risus laoreet a. Aliquam auctor porta maximus. Aliquam erat volutpat. Cras placerat facilisis nibh, efficitur ultricies magna rutrum vitae. Proin in sapien nunc. Nullam a felis vitae lacus rutrum tincidunt. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed nibh justo, condimentum nec elit id, posuere pharetra sem. Donec rhoncus eu tortor eu finibus. Morbi egestas auctor felis, eleifend sollicitudin nulla euismod id. Etiam vitae lacus accumsan, consequat lacus pulvinar, ornare orci. Pellentesque varius nibh sed neque egestas, a dignissim turpis vulputate. Praesent cursus gravida tortor, a posuere magna tempor a. Duis eu diam pellentesque, euismod nibh vitae, feugiat metus.")
f.close()
"""
"""
f1 = open("test1.txt","r")
#list = f1.readlines()
ch = f1.read(5)
print(ch)
f1.close()
"""

f = open("test1.txt","w")
list = ["\nbonjour tout le mode je suis nouveau dans cette convarsation\n Ineed somme help"]
f.writelines(list)
f.close()