import matplotlib.pyplot as plt
import numpy as np
 
def f(x):
    return np.power(x,4) + 2*np.power(x,2) + 1
def g(x):
    return 4*np.power(x,3) + 4*x
def F(x):
    return 2*x


x0 = 0.4
x1 = x0 - (f(x0)/g(x0))
eps = 0.00000005
i=0
print("{},   {:.2f},   {:.2f},   {:.2f},   {:.2f}".format(i,x1,f(x1),x0,g(x0),abs(x0-x1)))
for i in range(1,20):
    x0 = x1
    x1 = x0 - f(x0)/F(x0)
    print("{},   {:.2f},   {:.2f},   {:.2f},   {:.2f}".format(i,x1,f(x1),x0,g(x0),abs(x0-x1)))
    if(abs(x0-x1)<eps):
        break
print(i,x1,x0,abs(x0-x1))  
